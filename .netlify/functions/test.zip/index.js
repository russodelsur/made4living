// import a from "./a"
// import b from "./b"

const a = require("./a");
const b = require("./b")

const c = JSON.stringify(a) + JSON.stringify(b);

exports.handler = async () => {
    return {
        statusCode: 200, 
        body: c,
    }
};